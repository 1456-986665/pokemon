const apiKey = 'https://pokeapi.co/api/v2/pokemon/1/'; // 

document.getElementById('searchButton').addEventListener('click', () => {
    const pokemonName = document.getElementById('pokemonName').value.trim().toLowerCase();

    if (pokemonName !== '') {
        fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`)
            .then(response => response.json())
            .then(data => {
                displayPokemonInfo(data);
            })
            .catch(error => {
                console.error('Error al buscar el Pokémon:', error);
                displayPokemonInfo(null);
            });
    }
});

function displayPokemonInfo(pokemon) {
    const pokemonInfo = document.getElementById('pokemonInfo');

    if (pokemon === null) {
        pokemonInfo.innerHTML = 'Pokémon no encontrado.';
    } else {
        const html = `
            <h2>${pokemon.name}</h2>
            <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}">
            <p>ID: ${pokemon.id}</p>
            <p>Altura: ${pokemon.height / 10} m</p>
            <p>Peso: ${pokemon.weight / 10} kg</p>
            <p>Tipo(s): ${pokemon.types.map(type => type.type.name).join(', ')}</p>
        `;
        pokemonInfo.innerHTML = html;
    }
}

